<h3>Steps to Send Email</h3>
<ol>
  <li>Select email address from the list.</li>
  <li>Select available email subject.</li>
  <li>Click send email button.</li>
</ol>
