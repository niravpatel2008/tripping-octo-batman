<!--<br>
<table width="100%">
  <tr>
    <td align="left">
      <input name="btn_plugin_home" lang="btn_plugin_home" class="button-primary" onClick="location.href='options-general.php?page=email-newsletter/email-newsletter.php'" value="Home" type="button" />
      <input name="btn_compose_email_page" lang="btn_compose_email_page" class="button-primary" onClick="location.href='options-general.php?page=email-newsletter/email-compose.php'" value="Compose email" type="button" />
      <input name="btn_send_email_registered_user" lang="btn_send_email_registered_user" class="button-primary" onClick="location.href='options-general.php?page=email-newsletter/email-to-registered-user.php'" value="Send email to registered user" type="button" />
      <input name="btn_send_email_comment_posted_user" lang="btn_send_email_comment_posted_user" class="button-primary" onClick="location.href='options-general.php?page=email-newsletter/email-to-comment-posed-user.php'" value="Send email to comment posed user" type="button" />
      <input name="btn_send_email_subscriber" lang="btn_send_email_subscriber" class="button-primary" onClick="location.href='options-general.php?page=email-newsletter/email-to-subscriber.php'" value="Send email to subscriber" type="button" /></td>
  </tr>
</table>-->